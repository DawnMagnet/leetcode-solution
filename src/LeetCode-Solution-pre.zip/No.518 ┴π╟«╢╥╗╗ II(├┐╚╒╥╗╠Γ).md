原贴地址：[http://blog.leanote.com/post/dawnmagnet/lc518](http://blog.leanote
.com/post/dawnmagnet/lc518)
# 题目
<p>给定不同面额的硬币和一个总金额。写出函数来计算可以凑成总金额的硬币组合数。
假设每一种面额的硬币有无限个。&nbsp;</p>
<p>&nbsp;</p>
<ul>
</ul>
<p><strong>示例 1:</strong></p>
<pre><strong>输入:</strong> amount = 5, coins = [1, 2, 5]
<strong>输出:</strong> 4
<strong>解释:</strong> 有四种方式可以凑成总金额:
5=5
5=2+2+1
5=2+1+1+1
5=1+1+1+1+1
</pre>
<p><strong>示例 2:</strong></p>
<pre><strong>输入:</strong> amount = 3, coins = [2]
<strong>输出:</strong> 0
<strong>解释:</strong> 只用面额2的硬币不能凑成总金额3。
</pre>
<p><strong>示例 3:</strong></p>
<pre><strong>输入:</strong> amount = 10, coins = [10] 
<strong>输出:</strong> 1
</pre>
<p>&nbsp;</p>
<p><strong>注意</strong><strong>:</strong></p>
<p>你可以假设：</p>
<ul>
    <li>0 &lt;= amount (总金额) &lt;= 5000</li>
    <li>1 &lt;= coin (硬币面额)&nbsp;&lt;= 5000</li>
    <li>硬币种类不超过 500 种</li>
    <li>结果符合 32 位符号整数</li>
</ul>
# 思路分析
这个题非常简单，我们直接用dp的思想去思考即可。
状态量只有一个，就是金额，也就是说，我们对总金额amount进行dp即可。