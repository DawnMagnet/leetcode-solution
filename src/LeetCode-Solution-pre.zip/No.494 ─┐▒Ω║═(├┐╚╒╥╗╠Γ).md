原贴地址：[http://blog.leanote.com/post/dawnmagnet/lc494](http://blog.leanote
.com/post/dawnmagnet/lc494)
# 题目
<p>给你一个整数数组 <code>nums</code> 和一个整数 <code>target</code> 。</p>
<p>向数组中的每个整数前添加&nbsp;<code>'+'</code> 或 <code>'-'</code> 
，然后串联起所有整数，可以构造一个 <strong>表达式</strong> ：</p>
<ul>
    <li>例如，<code>nums = [2, 1]</code> ，可以在 <code>2</code> 之前添加 
    <code>'+'</code> ，在 <code>1</code> 之前添加 <code>'-'</code> 
    ，然后串联起来得到表达式 <code>"+2-1"</code> 。</li>
</ul>
<p>返回可以通过上述方法构造的、运算结果等于 <code>target</code> 的不同 
<strong>表达式</strong> 的数目。</p>
<p>&nbsp;</p>
<p><strong>示例 1：</strong></p>
<pre><strong>输入：</strong>nums = [1,1,1,1,1], target = 3
<strong>输出：</strong>5
<strong>解释：</strong>一共有 5 种方法让最终目标和为 3 。
-1 + 1 + 1 + 1 + 1 = 3
+1 - 1 + 1 + 1 + 1 = 3
+1 + 1 - 1 + 1 + 1 = 3
+1 + 1 + 1 - 1 + 1 = 3
+1 + 1 + 1 + 1 - 1 = 3
</pre>
<p><strong>示例 2：</strong></p>
<pre><strong>输入：</strong>nums = [1], target = 1
<strong>输出：</strong>1
</pre>
<p>&nbsp;</p>
<p><strong>提示：</strong></p>
<ul>
    <li><code>1 &lt;= nums.length &lt;= 20</code></li>
    <li><code>0 &lt;= nums[i] &lt;= 1000</code></li>
    <li><code>0 &lt;= sum(nums[i]) &lt;= 1000</code></li>
    <li><code>-1000 &lt;= target &lt;= 100</code></li>
</ul>
# 思路分析
一开始我有一个想法，就是使用HashSet来存储。
每一次读取到一个num，就将所有HashSet中的数字拿出来，加减num之后存到另一个Hash
Set中。