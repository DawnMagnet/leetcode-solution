原贴地址：[http://blog.leanote.com/post/dawnmagnet/lc168](http://blog.leanote
.com/post/dawnmagnet/lc168)
# 题目
<p>给你一个整数&nbsp;<code>columnNumber</code> ，返回它在 Excel 
表中相对应的列名称。</p>
<p>例如：</p>
<pre>A -&gt; 1
B -&gt; 2
C -&gt; 3
...
Z -&gt; 26
AA -&gt; 27
AB -&gt; 28 
...
</pre>
<p>&nbsp;</p>
<p><strong>示例 1：</strong></p>
<pre><strong>输入：</strong>columnNumber = 1
<strong>输出：</strong>"A"
</pre>
<p><strong>示例 2：</strong></p>
<pre><strong>输入：</strong>columnNumber = 28
<strong>输出：</strong>"AB"
</pre>
<p><strong>示例 3：</strong></p>
<pre><strong>输入：</strong>columnNumber = 701
<strong>输出：</strong>"ZY"
</pre>
<p><strong>示例 4：</strong></p>
<pre><strong>输入：</strong>columnNumber = 2147483647
<strong>输出：</strong>"FXSHRXW"
</pre>
<p>&nbsp;</p>
<p><strong>提示：</strong></p>
<ul>
    <li><code>1 &lt;= columnNumber &lt;= 2<sup>31</sup> - 1</code></li>
</ul>